import { html, render } from '../node_modules/lit-html/lit-html.js';

const url = 'http://localhost:3030/jsonstore/advanced/dropdown';

document.querySelector('form').addEventListener('submit', addItem);

const root = document.getElementById('menu');

onLoad(); // Corrected function name

async function onLoad() {
    const response = await fetch(url);
    const data = await response.json();
    const options = Object.values(data).map(option => optionTemplate(option));
    update(options);
}

function optionTemplate(option) {
    return html`<option value="${option._id}">${option.text}</option>`;
}

function update(data) {
    render(data, root);
}

function addItem(e) {
    e.preventDefault();
    const inputRef = document.getElementById('itemText');
    const text = inputRef.value;
    inputRef.value = '';

    if (text) {
        addItemToDB({ text }); // Pass the text in a data object
    }
}

async function addItemToDB(data) {
    const response = await fetch(url, {
        method: "POST",
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    });

    if (response.ok) {
        onLoad(); // Refresh the dropdown to show the new item
    }
}
